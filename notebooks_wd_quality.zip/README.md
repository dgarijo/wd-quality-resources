# wd-quality


Comprehensive Constraints Analysis - Final.ipynb - This notebook has the queries executed for the dataset to check type, value type, item requires, symmetric and inverse constraints.

Comprehensive Constraints Analysis - With Removed Statements - Final.ipynb - This notebook has the queries executed for the dataset with the removed statements to check type, value type, item requires, symmetric and inverse constraints. It is essentially the same notebook, but we run it twice with different data: once with all statements, and once with all statements + removed statements (see section 3.2 in the paper for more info)

Deprecated Statements Analysis - This notebook has the results of analysing deprecated statements.

Removed Statements Analysis.ipynb - This notebook has the queries executed to determine statistics of the removed statements.
