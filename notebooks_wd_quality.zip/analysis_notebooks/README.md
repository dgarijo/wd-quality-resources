# wd-quality


Comprehensive Constraints Analysis - Final.ipynb - This notebook has the queries executed for the dataset to check type, value type, item requires, symmetric and inverse constraints.

Comprehensive Constraints Analysis - With Removed Statements - Final.ipynb - This notebook has the queries executed for the dataset with the removed statements to check type, value type, item requires, symmetric and inverse constraints.

Deprecated Statements Analysis - Notebook containing the distribution of the deprecated statements in Wikidata.

Finalized Queries - Correct Segregation.ipynb - This notebook has the queries executed to determine statistics of the removed statements.
